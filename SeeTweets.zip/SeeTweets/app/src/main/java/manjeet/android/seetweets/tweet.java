package manjeet.android.seetweets;

/**
 * Created by manjeet on 6/29/16.
 */
public class tweet {
    public String userName;
    public String screenName;
    public String text="";
    public String profileImage;
    public String time;
    public tweet(String _userName,String _screenName,String _text,String _profileImage,String _time)
    {
        userName=_userName;
        screenName=_screenName;
        text=_text;
        profileImage=_profileImage;
        time=_time;
    }
}
