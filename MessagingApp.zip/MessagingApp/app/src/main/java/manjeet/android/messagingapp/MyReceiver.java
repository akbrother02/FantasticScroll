package manjeet.android.messagingapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by manjeet on 7/6/16.
 */
public class MyReceiver extends BroadcastReceiver {
    public static ArrayList<Message> messages=new ArrayList<>();

    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "MessageReceived", Toast.LENGTH_SHORT).show();
        Bundle bundle=intent.getExtras();
        Object[] objects=(Object[])bundle.get("pdus");
        for (int i = 0; i < objects.length; i++) {
            SmsMessage message=SmsMessage.createFromPdu((byte[])objects[i]);
            String number=message.getOriginatingAddress();
            String body=message.getMessageBody();
            Message msg=new Message(number,body);
            messages.add(msg);
        }
        try {
            MainActivity.getInstance().updateUI();
        }catch (Exception e)
        {
            Log.e("Error","Error updating UI "+e.getMessage());
        }
    }
}
