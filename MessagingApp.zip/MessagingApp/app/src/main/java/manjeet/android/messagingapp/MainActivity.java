package manjeet.android.messagingapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    public static MainActivity intance;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.textView);
    }
    public void updateUI()
    {
        ArrayList<Message> messages=MyReceiver.messages;
        int size=messages.size();
        String msg="Number: "+messages.get(size-1).number+"\n"
                +messages.get(size-1).messageBody;
        textView.setText(msg);

    }
    @Override
    public void onStart()
    {
        super.onStart();
        intance=this;
    }
    public static MainActivity getInstance()
    {
        return intance;
    }
}
