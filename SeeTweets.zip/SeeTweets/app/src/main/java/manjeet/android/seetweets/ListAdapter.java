package manjeet.android.seetweets;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by manjeet on 6/29/16.
 */
public class ListAdapter extends BaseAdapter {
    ArrayList<tweet> list;
    Context context;
    LayoutInflater inflater;
    public ListAdapter(Context _context,ArrayList<tweet> _list)
    {
        context=_context;
        list=_list;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    class Holder
    {
        TextView userName;
        TextView screenName;
        TextView time;
        TextView text;
        ImageView profileImage;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView==null) {
            convertView = inflater.inflate(R.layout.tweet_layout, null,false);
            holder=new Holder();
            holder.userName=(TextView)convertView.findViewById(R.id.userName);
            holder.screenName=(TextView)convertView.findViewById(R.id.screenName);
            holder.time=(TextView)convertView.findViewById(R.id.time);
            holder.text=(TextView)convertView.findViewById(R.id.text);
            holder.profileImage=(ImageView)convertView.findViewById(R.id.profileImage);
            convertView.setTag(holder);
        }
        else {
            holder=(Holder)convertView.getTag();
        }

        tweet item=getItem(position);
        holder.userName.setText(item.userName);
        holder.screenName.setText("@"+item.screenName);
        String[] tempTime=item.time.split(" ");
        holder.time.setText(tempTime[2]+" "+tempTime[1]);
        holder.text.setText(item.text);
        Picasso.with(context).load(item.profileImage).into(holder.profileImage);
        return convertView;
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public tweet getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


}
