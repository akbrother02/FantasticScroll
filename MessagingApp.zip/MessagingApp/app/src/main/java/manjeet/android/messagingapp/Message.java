package manjeet.android.messagingapp;

/**
 * Created by manjeet on 7/6/16.
 */
public class Message {
    public String number;
    public String messageBody;
    public Message(String _number,String _messageBody)
    {
        number=_number;
        messageBody=_messageBody;
    }
}
