package manjeet.android.seetweets;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by manjeet on 6/29/16.
 */
public class getTweets extends AsyncTask<Void,Void,String>  {
    public ArrayList<tweet> tweetsList=new ArrayList<>();
    ListView listView;
    Context context;
    static String consumerkey="1GldhpoIKtXqlzWn6SahkjFPs";
    static String consumersecret="sL5CBicTriSwr1nUK6WbcD0eoKFx3t3fPWv3bFGXhl7DRZ2qjH";
    static String bearertoken="";
    public String TwitterTokenURL="https://api.twitter.com/oauth2/token";
    public String TwitterStreamURL="https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=vsayindia&count=10";
    public getTweets(Context _context,ListView _listView)
    {
        context=_context;
        listView=_listView;
    }
    @Override
    protected String doInBackground(Void... params) {
        String result="Empty";
        try {
            String encodedConsumerKey = URLEncoder.encode(consumerkey, "UTF-8");
            String encodedConsumerSecret=URLEncoder.encode(consumersecret,"UTF-8");
            String combination=encodedConsumerKey+":"+encodedConsumerSecret;
            String encodedDetails= Base64.encodeToString(combination.getBytes(),Base64.NO_WRAP);
            URL url=null;
            url=new URL(TwitterTokenURL);
            HttpsURLConnection connection=null;
            connection=(HttpsURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Basic " + encodedDetails);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
            BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
            writer.write("grant_type=client_credentials");
            writer.flush();
            writer.close();
            JSONObject tokenObject=new JSONObject(readResponse(connection));
            if(tokenObject.getString("token_type").equals("bearer"))
            {
                bearertoken=tokenObject.getString("access_token");
            }
            else {
                bearertoken=null;
                connection.disconnect();
                IOException e=new IOException("could not get access token");
                throw e;
            }
            url=new URL(TwitterStreamURL);
            connection=(HttpsURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer " + bearertoken);
            JSONArray inputJsonArray=new JSONArray(readResponse(connection));
            /*
            String tweets="";
            if(inputJsonArray==null)
            {
                throw new IOException("Error reading jsonArray");
            }
            for (int index=0;index<inputJsonArray.length();index++)
            {
                tweets+="\n"+inputJsonArray.getJSONObject(index).getString("text");
            }*/
            return inputJsonArray.toString();

        }catch (IOException e)
        {
            Log.d("ErrorMessage",e.getMessage());
        } catch (JSONException e) {
            Log.d("ErrorMessage", e.getMessage());
        }
        return result;
    }
    public String readResponse(HttpsURLConnection connection) {
        try {
            StringBuilder str = new StringBuilder();

            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line = "";
            while((line = br.readLine()) != null) {
                str.append(line + System.getProperty("line.separator"));
            }
            return str.toString();
        }
        catch (IOException e) { return new String(); }
    }
    @Override
    protected void onPreExecute()
    {

    }
    @Override
    protected void onPostExecute(String result)
    {
        String userName;
        String screenName;
        String text;
        String profileImage;
        String time;
        try {
            JSONArray jsonArray=new JSONArray(result);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject tempObject=jsonArray.getJSONObject(i);
                time=tempObject.getString("created_at");
                text=tempObject.getString("text");
                tempObject=tempObject.getJSONObject("user");
                userName=tempObject.getString("name");
                screenName=tempObject.getString("screen_name");
                profileImage=tempObject.getString("profile_image_url");
                tweet newTweet=new tweet(userName,screenName,text,profileImage,time);
                tweetsList.add(newTweet);
            }
            ListAdapter adapter = new ListAdapter(context, tweetsList);
            System.out.println(tweetsList.size());
            listView.setAdapter(adapter);
        } catch (JSONException e) {
            Log.d("ErrorMessage",e.getMessage());
        }


    }
}
